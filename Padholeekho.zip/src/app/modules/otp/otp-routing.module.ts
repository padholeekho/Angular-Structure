import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { OtpComponent } from '../otp';

const routes: Routes = [  
  {
    path: '',
    component: OtpComponent,
  },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  }, 
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class OtpRoutingModule { }
