import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from '../register';

const routes: Routes = [  
  {
    path: '',
    component: RegisterComponent,
  },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  }, 
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class RegisterRoutingModule { }
