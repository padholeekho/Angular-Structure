import { Routes } from '@angular/router';

export const moduleRoutes : Routes = [
    { path: 'aboutUs', loadChildren: './modules/about/about.module#AboutModule' },
    { path: 'enquiry', loadChildren: './modules/enquiry/enquiry.module#EnquiryModule' },
    { path: 'login', loadChildren: './modules/login/login.module#LoginModule' },
    { path: 'OTP', loadChildren: './modules/otp/otp.module#OtpModule' } 
];