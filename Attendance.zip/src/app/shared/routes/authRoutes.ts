import { Routes } from '@angular/router';

export const CONSTANT_ROUTES : Routes = [
    { path: 'home', loadChildren: './modules/home/home.module#HomeModule' },
];