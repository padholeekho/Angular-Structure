import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core'; 
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './shared';
import { AppComponent } from './app.component';
import { FooterComponent, NavComponent, LayoutAuthComponent, LayoutContentComponent} from './layouts';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    NavComponent,
    LayoutAuthComponent,
    LayoutContentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SharedModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
