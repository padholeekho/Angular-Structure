import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-layout-auth',
  templateUrl: './layout-auth.component.html',
  styleUrls: ['./layout-auth.component.css']
})
export class LayoutAuthComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
