import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutAuthComponent, LayoutContentComponent } from './layouts'; 
import { CONSTANT_ROUTES } from './shared'; 
import { AuthGuard } from './core';

const routes: Routes = [
  { 
    path: '', 
    redirectTo: '/auth/login', 
    pathMatch: 'full' 
  }, 
  { 
    path: 'home',  
    component: LayoutContentComponent,  
    canActivate: [AuthGuard],
    children: CONSTANT_ROUTES
  },
  { 
    path: 'auth', 
    component: LayoutAuthComponent, 
    loadChildren: './modules/auth/auth.module#AuthModule' 
  },
  { path: '**', redirectTo: '/auth/login', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
