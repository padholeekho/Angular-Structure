import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthguardService {

  constructor() { }

  getToken(){
    console.log('calls');
    return true;
  }

}
