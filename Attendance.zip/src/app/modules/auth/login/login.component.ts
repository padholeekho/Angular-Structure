import { Component, OnInit } from '@angular/core';
import { of } from 'rxjs';
import { tap, filter, map, scan } from 'rxjs/operators';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    of(1, 2, 3, 4).pipe( 
      filter(n => n % 2 === 0), 
      map(n => n + 10), 
      scan((sum, n) => sum + n), 
    ).subscribe(result => console.log("Result: " + result));
  }

}
